from nicegui import ui


def create_downloads_page():
    # ...existing code from create_downloads_page...
    pass
