"""Protobuf definitions for websocket feeds."""
